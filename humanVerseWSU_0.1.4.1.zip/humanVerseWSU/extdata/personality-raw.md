# "personality-raw" data set

This data is owned by the `humanVerseWSU` author.  

It is a good use case of data cleansing (hence `-raw`).

It is a useful example for multivariate analysis.

The author's records are tied to `md5_email == "b8cdc5fef066412beb9dd1d9ec1acad0"`.




